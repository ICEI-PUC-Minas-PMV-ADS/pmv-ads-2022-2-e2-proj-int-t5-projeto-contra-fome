
localStorage.removeItem('usuario')